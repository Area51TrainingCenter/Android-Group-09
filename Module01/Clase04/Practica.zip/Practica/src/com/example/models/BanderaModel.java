package com.example.models;

public class BanderaModel {

	protected int imgBandera;

	public int getImgBandera() {
		return imgBandera;
	}

	public void setImgBandera(int imgBandera) {
		this.imgBandera = imgBandera;
	}

}
