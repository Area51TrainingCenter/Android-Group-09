package com.example.models;

public class EquipoModel {

	protected String nombreEquipo;
	protected String detalleEquipo;
	protected int imgEquipo;

	public String getNombreEquipo() {
		return nombreEquipo;
	}

	public void setNombreEquipo(String nombreEquipo) {
		this.nombreEquipo = nombreEquipo;
	}

	public String getDetalleEquipo() {
		return detalleEquipo;
	}

	public void setDetalleEquipo(String detalleEquipo) {
		this.detalleEquipo = detalleEquipo;
	}

	public int getImgEquipo() {
		return imgEquipo;
	}

	public void setImgEquipo(int imgEquipo) {
		this.imgEquipo = imgEquipo;
	}

}
