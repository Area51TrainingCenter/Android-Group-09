package com.example.utils;

import java.util.ArrayList;

import com.example.models.EquipoModel;

public class Constantes {

	public static ArrayList<EquipoModel> arreglo;
	
	public static EquipoModel modelotmp;
	
	public static int imagen = 0;
	public static String titulo = "";
	public static String detalle = "";
	
	

}
