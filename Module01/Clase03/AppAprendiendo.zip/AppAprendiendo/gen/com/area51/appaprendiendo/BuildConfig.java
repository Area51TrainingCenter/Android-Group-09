/** Automatically generated file. DO NOT MODIFY */
package com.area51.appaprendiendo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}