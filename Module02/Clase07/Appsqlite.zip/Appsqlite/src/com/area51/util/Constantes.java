package com.area51.util;

public class Constantes {

}
