/** Automatically generated file. DO NOT MODIFY */
package com.area51.appsqlite;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}