package com.area51.fragments;

import android.support.v4.app.Fragment;

public class InicioFragment extends Fragment {

}
