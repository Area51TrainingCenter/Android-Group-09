<?php

/*
$direcciones = new stdClass();
$direcciones->controlador = '';
$direcciones->metodo = '';
$direcciones->parametro = '';


if( isset($_GET['url'])  && !empty($_GET['url']) ){

	$aux = explode('/', $_GET['url']);
	$direcciones->controlador = $aux[0];
	$direcciones->metodo = $aux[1];
	$direcciones->parametro = $aux[2];
}


switch ($direcciones->controlador) {
	case 'usuarios':
		//require_once 'usuarios.php';
		break;
}



print_r($direcciones);


/*
print_r($_GET['url']);

/*
$pokemon = new stdClass();

$pokemon->nombre = "Charmander";
$pokemon->tipo = "Fuego";

//print_r($pokemon);

//Arreglos

$arreglo = array("nombre"=>"Charmander");
$arreglo["tipo"] = "Fuego";

//print_r($arreglo);

echo md5("segu19");
echo '<br>';

$elementos = count($arreglo);

for ($i=0; $i < $elementos ; $i++) { 
	
}


//0 1 1 2 3 5 8 13




//Imprimir un json
echo json_encode($arreglo);
*/

?>