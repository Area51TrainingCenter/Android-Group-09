<?php

//Importar clases(archivos) de php
require_once 'pokemon.php';

//Creamos una instancia de pokemon
$objPokemon = new Pokemon();

$objPokemon->creaPokemon("Charmander", "Fuego");



//Pokemon::eliminaPokemon();


?>