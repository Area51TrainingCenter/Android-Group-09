<?php
//Código PHP

//Area51
$persona = "Area51";
//$persona = 2014;

//echo "Estudio en $persona";

//echo 'Estudio en '.$persona;

//print( $persona );

?>