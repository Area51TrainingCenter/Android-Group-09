package com.area51.utils;

public class Constantes {

	public static String API 
		= "http://segundoacosta.com/";
	
	public static String API_VERSION 
		= "area51api/";

	
	public static String API_SECTION 
		= "listado.php";

	
}
