/** Automatically generated file. DO NOT MODIFY */
package com.area51.twitterapp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}