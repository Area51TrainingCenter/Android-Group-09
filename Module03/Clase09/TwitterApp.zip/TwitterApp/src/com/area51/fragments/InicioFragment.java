package com.area51.fragments;

import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Toast;

import com.area51.adapters.TweetAdapter;
import com.area51.async.ManageTweet;
import com.area51.twitterapp.R;
import com.area51.utils.ConstantsApp;
import com.area51.utils.NetworkApp;
import com.nhaarman.listviewanimations.swinginadapters.prepared.SwingBottomInAnimationAdapter;

public class InicioFragment extends Fragment {

	ListView listainicio;
	LinearLayout capacargando;
	
	ManageTweet mt;
	
	//PARA LA ANIMACION
	SwingBottomInAnimationAdapter sbiaa;

	@Override
	public View onCreateView(LayoutInflater inflater,
			@Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

		View view = inflater.inflate(R.layout.fragment_inicio, null, false);

		listainicio = (ListView) view.findViewById(R.id.listaInicio);
		capacargando = (LinearLayout) view.findViewById(R.id.capacargando);

		return view;
	}

	@Override
	public void onResume() {

		super.onResume();

		mt = new ManageTweet(getActivity());
		
		
		
		// Verificar la conexi�n de red
		NetworkApp conexion = new NetworkApp(getActivity());

		if (conexion.getNetwork()) {
			// Llamamos al rest api o web services
			new InicioAsync().execute();

		} else {
			// Llamamos a sqlite
		}

	}

	public void mostrarTweets( TweetAdapter adapter ){
		
		//Ocultamos el layout con el loader
		capacargando.setVisibility(View.GONE);
		
		//Verificamos que haya informaci�n
		
		if( !adapter.isEmpty() ){
			
			listainicio.setVisibility(View.VISIBLE);
			
			sbiaa = new SwingBottomInAnimationAdapter(
					new SwingBottomInAnimationAdapter(adapter)
			);
			
			sbiaa.setAnimationDelayMillis(300);
			sbiaa.setAbsListView(listainicio);
			
			listainicio.setAdapter(sbiaa);
						
			
		}else{
			//Mostramos un mensaje
			Toast.makeText(
					getActivity(), 
					R.string.texto_dato_vacio , 
					Toast.LENGTH_SHORT).show();
			
		}
		
		
	}
	
	
	class InicioAsync extends AsyncTask<Object, Void, TweetAdapter> {

		@Override
		protected void onPreExecute() {
			super.onPreExecute();			
		}	

		@Override
		protected TweetAdapter doInBackground(Object... params) {
			
			return mt.getHashtagAdapter(ConstantsApp.TWITTER_TERM);
		}

		@Override
		protected void onPostExecute(TweetAdapter result) {
			
			super.onPostExecute(result);
			Log.d("InicioAsync", "doInBackground");
			
			mostrarTweets(result);			
		}

	}

}
